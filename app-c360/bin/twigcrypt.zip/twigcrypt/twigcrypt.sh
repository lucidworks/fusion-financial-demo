java -classpath .:guice-4.0.jar:guava-18.0.jar:javax.inject-1.jar:jasypt-1.9.0.jar twigkit.crypto.ConfigurationEncryptor $1 $2
